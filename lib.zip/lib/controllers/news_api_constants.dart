class NewsApiConstants {
  static const String newsApiKey = 'bdef231edfd94844a127fa555baed96d';
}
