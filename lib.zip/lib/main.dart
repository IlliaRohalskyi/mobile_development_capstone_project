import 'package:flutter/material.dart';
import 'screens/home_screen.dart';


void main() async {
  runApp(HomeScreen());
}
