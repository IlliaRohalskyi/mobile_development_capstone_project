import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobile_development_capstone_project/controllers/getx_controller.dart';

var listOfCountry = [
  {"name": "INDIA", "code": "in"},
  {"name": "USA", "code": "us"},
  {"name": "UK", "code": "gb"},
  {"name": "MEXICO", "code": "mx"},
  {"name": "United Arab Emirates", "code": "ae"},
  {"name": "New Zealand", "code": "nz"},
  {"name": "Australia", "code": "au"},
  {"name": "Canada", "code": "ca"},
];

var listOfCategory = [
  {"name": "Science", "code": "science"},
  {"name": "Business", "code": "business"},
  {"name": "Technology", "code": "technology"},
  {"name": "Sports", "code": "sports"},
  {"name": "Health", "code": "health"},
  {"name": "General", "code": "general"},
  {"name": "Entertainment", "code": "entertainment"},
  {"name": "ALL", "code": null},
];
var listOfNewsChannel = [
  {"name": "BBC News", "code": "bbc-news"},
  {"name": "ABC News", "code": "abc-news"},
  {"name": "The Times of India", "code": "the-times-of-india"},
  {"name": "ESPN Cricket", "code": "espn-cric-info"},
  {"code": "politico", "name": "Politico"},
  {"code": "the-washington-post", "name": "The Washington Post"},
  {"code": "reuters", "name": "Reuters"},
  {"code": "cnn", "name": "cnn"},
  {"code": "nbc-news", "name": "NBC news"},
  {"code": "the-hill", "name": "The Hill"},
  {"code": "fox-news", "name": "Fox News"},
];

GestureDetector drawerDropDown({name, onCalled}) {
  return GestureDetector(
      child: ListTile(title: Text(name)), onTap: () => onCalled());
}

class CustomDrawer extends StatelessWidget {
  final Controller newsController;

  const CustomDrawer(this.newsController);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFFD3D3D3),
      child: ListView(
        children: <Widget>[
          GetBuilder<Controller>(
            builder: (controller) {
              return Container(
                decoration: const BoxDecoration(
                    color: const Color(0xFF16a085),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(10),
                    bottomRight: Radius.circular(10),
                  ),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 18, 
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    controller.cName.isNotEmpty
                        ? Text(
                            "Country: ${controller.cName.value.capitalizeFirst}",
                            style: const TextStyle(
                                color: Colors.white,
                              fontSize: 18,
                            ),
                          )
                        : const SizedBox.shrink(),
                    const SizedBox(height: 15),
                    controller.category.isNotEmpty
                        ? Text(
                            "Category: ${controller.category.value.capitalizeFirst}",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                            ),
                          )
                        : const SizedBox.shrink(),
                    const SizedBox(height: 15),
                    controller.channel.isNotEmpty
                        ? Text(
                            "Category: ${controller.channel.value.capitalizeFirst}",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                            ),
                          )
                        : const SizedBox.shrink(),
                  ],
                ),
              );
            },
            init: Controller(),
          ),
          ExpansionTile(
            collapsedTextColor: const Color(0xFF16a085),
            collapsedIconColor: const Color(0xFF16a085),
            iconColor: const Color(0xFF16a085),
            textColor: const Color(0xFF16a085),
            title: const Text("Select Country"),
            children: <Widget>[
              for (int i = 0; i < listOfCountry.length; i++)
                drawerDropDown(
                  onCalled: () {
                    newsController.country.value = listOfCountry[i]['code']!;
                    newsController.cName.value =
                        listOfCountry[i]['name']!.toUpperCase();
                    newsController.getAllNews();
                    newsController.getBreakingNews();
                  },
                  name: listOfCountry[i]['name']!.toUpperCase(),
                ),
            ],
          ),
          ExpansionTile(
            collapsedTextColor: const Color(0xFF16a085),
            collapsedIconColor: const Color(0xFF16a085),
            iconColor: const Color(0xFF16a085),
            textColor: const Color(0xFF16a085),
            title: const Text("Select Category"),
            children: [
              for (int i = 0; i < listOfCategory.length; i++)
                drawerDropDown(
                  onCalled: () {
                    newsController.category.value = listOfCategory[i]['code']!;
                    newsController.getAllNews();
                  },
                  name: listOfCategory[i]['name']!.toUpperCase(),
                )
            ],
          ),
          ExpansionTile(
            collapsedTextColor: const Color(0xFF16a085),
            collapsedIconColor: const Color(0xFF16a085),
            iconColor: const Color(0xFF16a085),
            textColor: const Color(0xFF16a085),
            title: const Text("Select Channel"),
            children: [
              for (int i = 0; i < listOfNewsChannel.length; i++)
                drawerDropDown(
                  onCalled: () {
                    newsController.channel.value =
                        listOfNewsChannel[i]['code']!;
                    newsController.getAllNews(
                        channel: listOfNewsChannel[i]['code']);
                  },
                  name: listOfNewsChannel[i]['name']!.toUpperCase(),
                ),
            ],
          ),
          const Divider(),
          ListTile(
            trailing: const Icon(
              Icons.done_sharp,
              size: 28,
              color: Colors.black,
            ),
            title: const Text(
              "Done",
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
              ),
            ),
            onTap: () => Get.back(),
          ),
        ],
      ),
    );
  }
}
