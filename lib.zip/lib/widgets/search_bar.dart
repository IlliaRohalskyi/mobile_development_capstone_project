import 'package:flutter/material.dart';
import 'package:mobile_development_capstone_project/controllers/getx_controller.dart';

class NewsSearchDrawer extends StatelessWidget {
  final TextEditingController searchController;
  final Controller newsController;

  const NewsSearchDrawer({
    Key? key,
    required this.searchController,
    required this.newsController,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        margin: const EdgeInsets.symmetric(
            horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8)),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              fit: FlexFit.tight,
              flex: 4,
              child: Padding(
                padding: const EdgeInsets.only(left: 16),
                child: TextField(
                  controller: searchController,
                  textInputAction: TextInputAction.search,
                  decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: "Search News"),
                  onChanged: (val) {
                    newsController.searchNews.value = val;
                    newsController.update();
                  },
                  onSubmitted: (value) async {
                    newsController.searchNews.value = value;
                    newsController.getAllNews(
                        searchKey: newsController.searchNews.value);
                    searchController.clear();
                  },
                ),
              ),
            ),
            Flexible(
              flex: 1,
              fit: FlexFit.tight,
              child: IconButton(
                  padding: EdgeInsets.zero,
                    color: const Color(0xFF16a085), // Assuming this is defined elsewhere
                  onPressed: () async {
                    newsController.getAllNews(
                        searchKey: newsController.searchNews.value);
                    searchController.clear();
                  },
                  icon: const Icon(Icons.search_sharp)),
            ),
          ],
        ),
      ),
    );
  }
}
